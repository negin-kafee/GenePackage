# GenePackage 0.1.0

* Initial release of the package with S4 classes for various gene types.
